function init
{
	echo "Getting config data"

	if [ -e /boot/pi.conf ]
	then
		echo "Using /boot/pi.conf"
		RaspberryPiID=$(echo -n `cat /boot/pi.conf`)
	else
		echo "Using pi.conf"
		RaspberryPiID=$(echo -n `cat pi.conf`)
	fi

	# RaspberryPiID="RP00003699"

	echo "RaspberryPiID: $RaspberryPiID"

	EC2Instance=$(curl -s "https://adsrental.com/app/log/?rpid=$RaspberryPiID&h")

	echo "EC2Instance: $EC2Instance"
}