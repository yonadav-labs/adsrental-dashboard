#!/bin/bash

if [ $# -eq 0 ]
	then
		echo "No arguments supplied to keepalive"
		exit
fi

RaspberryPiID=$1

echo "Starting continuous ping for $RaspberryPiID..."

while true
do
	echo "Ping"
	RESPONSE=$(curl "https://adsrental.com/rlog.php?rpid=$RaspberryPiID&p")
	if [[ $RESPONSE == *"\"restart\": true"* ]]; then
		echo "Restarting RaspberryPi"
		sudo reboot
	fi
	if [[ $RESPONSE == *"\"pull\": true"* ]]; then
		echo "Pulling changes and restart"
		curl https://adsrental.com/static/new_pi.zip > new_pi.zip
		unzip -o new_pi.zip
		sudo reboot
	fi
	sleep 1m
done
