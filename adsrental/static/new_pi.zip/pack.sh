#!/bin/bash
zip -r new_pi.zip *.sh
cp new_pi.zip ../dashboard/adsrental/static
