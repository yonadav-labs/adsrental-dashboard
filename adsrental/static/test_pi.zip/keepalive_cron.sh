#!/bin/bash

RASPBERRYPI_ID="$(echo -n `cat ~/rpid.conf`)"
EC2_INSTANCE="$(echo -n `cat ~/hostname.conf`)"
VERSION="$(echo -n `cat /home/pi/new-pi/version.txt`)"

EC2_INSTANCE_PORT="13608"

TROUBLESHOOT="$1"

QUERY="rpid=${RASPBERRYPI_ID}&p&hostname=${EC2_INSTANCE}&version=${VERSION}"

if [[ "$TROUBLESHOOT" == "--troubleshoot" ]] {
    curl -G "https://adsrental.com/app/log/?rpid=${RASPBERRYPI_ID}" --data-urlencode "client_log=Troubleshooting connection"

    TUNNEL_UP="1"
    if [[ "$( ps aux | grep -v grep | grep ssh | grep 2046:localhost )" == "" ]]; then
        TUNNEL_UP="10"
    fi
    if [[ "$( ssh -o StrictHostKeyChecking=no Administrator@${EC2_INSTANCE} -p 40594 'netstat -an' | grep 'LISTENING' | grep '1:2046' )" == "" ]]; then
        TUNNEL_UP="11"
    fi

    INSTANCE_ID="$(curl -q --max-time 10 http://${EC2_INSTANCE}:${EC2_INSTANCE_PORT})"
    QUERY="${QUERY}&troubleshoot=true&instance_id=${INSTANCE_ID}&tunnel_up=${TUNNEL_UP}"
}

RESPONSE=$(curl "https://adsrental.com/app/log/?${QUERY}")
if [[ $RESPONSE == *"\"restart\": true"* ]]; then
    echo "Restarting RaspberryPi"
    curl -G "https://adsrental.com/app/log/?rpid=${RASPBERRYPI_ID}" --data-urlencode "client_log=Restarting RaspberryPi"
    curl https://adsrental.com/static/update_pi.sh | bash
fi
