#!/bin/bash

if [ $# -eq 0 ]
	then
		echo "No arguments supplied to keepalive"
		exit
fi

RaspberryPiID="$1"
EC2Instance="$2"
VERSION=$(echo -n `cat version.txt`)
TUNNEL_UP="1"
INSTANCE_ID=""
COUNTER=0
EC2_INSTANCE_PORT="13608"

echo "Starting continuous ping for $RaspberryPiID..."

while true
do
	TUNNEL_UP="0"
	if [[ $(ps aux | grep -v grep | grep ssh | grep 2046:localhost ) = *ssh* ]]; then
		TUNNEL_UP="1"
	fi

	COUNTER=$((COUNTER + 1))
	QUERY="rpid=${RaspberryPiID}&p&hostname=${EC2Instance}&version=${VERSION}&counter=${COUNTER}&tunnel_up=${TUNNEL_UP}"
	MINUTES_LAST=`date +%M | cut -c 2`

	# Do every 10 pings
	if [[ $COUNTER -gt 5 ]]; then
		COUNTER=0
		curl -G "https://adsrental.com/app/log/?rpid=$RaspberryPiID" --data-urlencode "client_log=Troubleshooting connection"
		INSTANCE_ID="$(curl -q --connect-timeout 5 http://${EC2Instance}:${EC2_INSTANCE_PORT})"
		QUERY="${QUERY}&troubleshoot=true&instance_id=${INSTANCE_ID}"
	fi
	echo "Ping"
	RESPONSE=$(curl "https://adsrental.com/app/log/?${QUERY}")
	if [[ $RESPONSE == *"\"restart\": true"* ]]; then
		echo "Restarting RaspberryPi"
		curl -G "https://adsrental.com/app/log/?rpid=$RaspberryPiID" --data-urlencode "client_log=Restarting RaspberryPi"
		curl https://adsrental.com/static/update_pi.sh | bash
	fi
	sleep 2m
done
