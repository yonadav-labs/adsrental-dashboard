function init
{
	echo "Getting config data"

	if [ -e /boot/pi.conf ]
	then
		echo "Using /boot/pi.conf"
		RaspberryPiID=$(echo -n `cat /boot/pi.conf`)
	else
		echo "Using pi.conf"
		RaspberryPiID=$(echo -n `cat pi.conf`)
	fi

	# RaspberryPiID="RP00003699"

	echo "RaspberryPiID: $RaspberryPiID"

	EC2Instance=$(curl -s "https://adsrental.com/app/log/?rpid=$RaspberryPiID&h")

	while [[ $EC2Instance != ec2* ]]; do
		sleep 60
		curl -G "https://adsrental.com/app/log/?rpid=$RaspberryPiID" --data-urlencode "client_log=Getting EC2 hostname, retry"
		echo "Getting EC2 hostname, retry"
		EC2Instance=$(curl -s "https://adsrental.com/app/log/?rpid=$RaspberryPiID&h")
	done

	echo "EC2Instance: $EC2Instance"
	echo "$EC2Instance" > ~/hostname.conf
	echo "$RaspberryPiID" > ~/rpid.conf

	curl -G "https://adsrental.com/app/log/?rpid=$RaspberryPiID" --data-urlencode "client_log=Got config data: $RaspberryPiID $EC2Instance"
}