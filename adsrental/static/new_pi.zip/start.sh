#!/bin/sh

cd /home/pi/new-pi
./main.sh | ./logger.sh
