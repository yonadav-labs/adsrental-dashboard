#!/bin/bash
zip -r new_pi.zip *.sh version.txt
cp new_pi.zip ../dashboard/adsrental/static
