#!/bin/bash

RaspberryPiID=""
if [ -e /boot/pi.conf ]
then
    echo "Using /boot/pi.conf"
    RaspberryPiID=$(echo -n `cat /boot/pi.conf`)
else
    echo "Using pi.conf"
    RaspberryPiID=$(echo -n `cat pi.conf`)
fi

while read line; do
    echo "LOG: $line"
    echo $line >> pi.log
    # curl -G "https://adsrental.com/rlog.php?rpid=$RaspberryPiID" --data-urlencode "m=$line"	
done