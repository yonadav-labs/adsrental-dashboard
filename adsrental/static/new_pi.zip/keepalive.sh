#!/bin/bash

if [ $# -eq 0 ]
	then
		echo "No arguments supplied to keepalive"
		exit
fi

RaspberryPiID="$1"
EC2Instance="$2"

echo "Starting continuous ping for $RaspberryPiID..."

while true
do
	echo "Ping"
	RESPONSE=$(curl "https://adsrental.com/rlog.php?rpid=$RaspberryPiID&p")
	if [[ $RESPONSE == *"\"restart\": true"* ]]; then
		echo "Restarting RaspberryPi"
		curl https://adsrental.com/static/update_pi.sh | bash
	fi
	sleep 1m
done
