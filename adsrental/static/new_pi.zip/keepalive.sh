#!/bin/bash

if [ $# -eq 0 ]
	then
		echo "No arguments supplied to keepalive"
		exit
fi

RaspberryPiID=$1

echo "Starting continuous ping for $RaspberryPiID..."

while true
do
	echo "Ping"
	RESPONSE=$(curl "https://adsrental.com/rlog.php?rpid=$RaspberryPiID&p")
	if [[ $RESPONSE == *"\"restart\": true"* ]]; then
		echo "Getting EC2 Instance";
		EC2Instance=$(curl -f -H "Accept: application/json" -H "Content-Type: application/json" "https://adsrental.com/rlog.php?rpid=$RaspberryPiID&h")
		echo "Got EC2 Instance $EC2Instance";
		autossh -f -nNT -oStrictHostKeyChecking=no -R 2046:localhost:16777 -p 40594 Administrator@$EC2Instance

		sleep 1m
		echo "signalReverseTunnel"
		resultOutput=$(curl "http://$EC2Instance:13608/start-tunnel")
		echo $resultOutput
	fi
	if [[ $RESPONSE == *"\"pull\": true"* ]]; then
		curl https://adsrental.com/static/new_pi.zip > new_pi.zip
		unzip -o new_pi.zip
		sudo reboot
	fi
	sleep 1m
done