#!/bin/bash
zip -r new_pi.zip *.sh *.txt
cp new_pi.zip ../dashboard/adsrental/static/test_pi.zip
