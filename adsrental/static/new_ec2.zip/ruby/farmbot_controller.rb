require 'json'
require 'base64'
require 'sinatra'
require 'unirest'
require 'pathname'
require 'net/ssh'

set :run, true
set :bind, '0.0.0.0'
set :port, 13608

FARMBOT = 'C:\\Users\\Administrator\\Desktop\\auto\\fb.sikuli\\siku.bat'.freeze
FARMBOT_SETTINGS = 'C:\\Users\\Administrator\\Desktop\\auto\\fb.sikuli\\settings.json'.freeze
SSH_TUNNEL_CMD = 'ssh -D 3808 -p 2046 pi@localhost -N'.freeze

STATE = {
'FARMBOT_PID' => nil,
'TUNNEL_PID' => nil,
'RPID' => nil
}


def check_process(pid)
    if pid == nil
        # No PID set; NOT running
        return false
    else
        begin
            # If no exception occurs, then the farmbot is running
            Process.kill(0, pid)
            return true
        rescue
            # Exception occurred, so the farmbot is NOT running
            return false
        end
    end
    
    return nil
end


def get_instance_id()
    response = Unirest.get 'http://169.254.169.254/latest/meta-data/instance-id'
    response.body
end


def handle_start_farmbot(id, code)
    puts "Starting Farmbot"
    
    if not update_fb_creds(id, code)
        return [500, {}, ["ERROR-START-FARMBOT: Failed to update credentials"]]
    end
    
    if STATE['FARMBOT_PID'] != nil
        # @TODO do we want this to be an error?
        ret_hash = {
        'message' => "WARNING-START-FARMBOT: Farmbot already running: #{STATE['FARMBOT_PID']}",
        'running' => true
        }
        return [200, {}, [JSON.generate(ret_hash)]]
    end
    
    STATE['FARMBOT_PID'] = spawn(FARMBOT)
    Process.detach(STATE['FARMBOT_PID'])
    
    if STATE['FARMBOT_PID'] != nil
        ret_hash = {
        'message' => "Farmbot is running: #{STATE['FARMBOT_PID']}",
        'running' => true
        }
        return [200, {}, [JSON.generate(ret_hash)]]
    else
        return [500, {}, ["ERROR-START-FARMBOT: Failed to start Farmbot"]]
    end
    
    return [501, {}, ["ERROR-START-FARMBOT: Reached unreachable code"]]
end


def handle_stop_farmbot()
    puts "Stopping Farmbot"
    
    if STATE['FARMBOT_PID'] == nil
        # @TODO do we want this to be an error?
        ret_hash = {
        'message' => "WARNING-STOP-FARMBOT: Farmbot already stopped.",
        'running' => false
        }
        return [200, {}, [JSON.generate(ret_hash)]]
    end
    
    if system("taskkill /f /pid #{STATE['FARMBOT_PID']}")
        STATE['FARMBOT_PID'] = nil
        ret_hash = {
        'message' => "Farmbot has been stopped.",
        'running' => false
        }
        return [200, {}, [JSON.generate(ret_hash)]]
    else
        return [500, {}, ["ERROR-STOP-FARMBOT: Failed to stop Farmbot"]]
    end
end


def update_fb_creds(id, code)
    email = Base64.decode64(id)
    password = Base64.decode64(code)
    
    # Edit the settings.json file so that the email and password are stored there
    settings = nil

    File.open(FARMBOT_SETTINGS) do |file|
        settings = JSON.parse(file.read)
    end

    settings['fb']['email'] = email
    settings['fb']['password'] = password

    File.open(FARMBOT_SETTINGS, "w") do |file|
        file.write(JSON.generate(settings))
    end
    
    return true
end


########################
#### Sinatra Routes ####
########################

get '/' do
    return [200, {}, [get_instance_id()]]
end


#------------------------------ FARMBOT ------------------------------
get '/farmbot-status' do
    status = check_process(STATE['FARMBOT_PID'])
    
    if status == nil
        return [501, {}, ["ERROR-FARMBOT-STATUS: Reached unreachable code"]]
    end
    
    return [200, {}, [JSON.generate({'status' => status})]]
end


get '/toggle-farmbot' do
    # matches "GET /toggle-farmbot?ID=X&CODE=Y"
    if params['ID'] == nil
        return [400, {}, ["ERROR-TOGGLE-FARMBOT: Missing required ID parameter"]]
    elsif params['CODE'] == nil
        return [400, {}, ["ERROR-TOGGLE-FARMBOT: Missing required CODE parameter"]]
    end
    
    r = check_process(STATE['FARMBOT_PID'])
    
    if r == nil
        return [500, {}, ["ERROR-TOGGLE-FARMBOT: Failed to determine farmbot status"]]
    elsif r
        return handle_stop_farmbot()
    else
        return handle_start_farmbot(params['ID'], params['CODE'])
    end
    
    return [501, {}, ["ERROR-TOGGLE-FARMBOT: Reached unreachable code"]]
end


get '/start-farmbot' do
    # matches "GET /start-farmbot?ID=X&CODE=Y"
    if params['ID'] == nil
        return [400, {}, ["ERROR-START-FARMBOT: Missing required ID parameter"]]
    elsif params['CODE'] == nil
        return [400, {}, ["ERROR-START-FARMBOT: Missing required CODE parameter"]]
    end
    
    return handle_start_farmbot(params['ID'], params['CODE'])
end


get '/stop-farmbot' do
    # matches "GET /stop-farmbot"
    return handle_stop_farmbot()
end


#------------------------------ TUNNEL ------------------------------
get '/tunnel-status' do
    status = check_process(STATE['TUNNEL_PID'])
    
    if status == nil
        return [501, {}, ["ERROR-FARMBOT-STATUS: Reached unreachable code"]]
    end
    
    return [200, {}, [JSON.generate({'status' => status})]]
end

def ssh_try(user, host, pass)
    puts "SSHing #{host} ..."
    Net::SSH.start( host.to_s, user.to_s, :password => pass.to_s ) do |ssh|
        puts ssh.exec!('date')
        puts "Logging out..."
    end
end

def get_rpid_from_rpi
    rpid = nil
    begin
        Net::SSH.start('localhost', 'pi', :port => 2046, :timeout => 10) do |ssh|
        rpid = ssh.exec!('cat /boot/pi.conf');
    end 
    rescue Net::SSH::ConnectionTimeout
        @error = "  Timed out"
    rescue Errno::EHOSTUNREACH
        @error = "  Host unreachable"
    rescue Errno::ECONNREFUSED
        @error = "  Connection refused"
    rescue Net::SSH::AuthenticationFailed
        @error = "  Authentication failure"
    end
    return rpid
end


get '/start-tunnel' do
    # matches "GET /start-tunnel"
    # ssh -D 3808 -p 2046 pi@localhost
    # password is pi
    # need to have the ssh tunnel expose a SOCKS 5 proxy
    rpid = get_rpid_from_rpi();
    if rpid == nil
        return [500, {}, ["ERROR-START-TUNNEL: RaspberryPi is not connected. Make sure it has internet connection and reset it."]]
    end

    STATE['TUNNEL_PID'] = spawn(SSH_TUNNEL_CMD)
    STATE['RPID'] = rpid
    Process.detach(STATE['TUNNEL_PID'])
    
    if STATE['TUNNEL_PID'] != nil
        return [200, {}, ["SSH Tunnel is running: #{STATE['TUNNEL_PID']} for #{STATE['RPID']}"]]
    else
        return [500, {}, ["ERROR-START-TUNNEL: Failed to start SSH Tunnel"]]
    end
end


get '/stop-tunnel' do
    # matches "GET /stop-tunnel"
    if STATE['TUNNEL_PID'] == nil
        # @TODO do we want this to be an error?
        return [200, {}, ["ERROR-STOP-TUNNEL: SSH Tunnel is already stopped."]]
    end
    
    if system("taskkill /f /pid #{STATE['TUNNEL_PID']}")
        STATE['TUNNEL_PID'] = nil
        return [200, {}, ["SSH Tunnel has been stopped."]]
    else
        return [500, {}, ["ERROR-STOP-TUNNEL: Failed to stop SSH Tunnel"]]
    end
end
