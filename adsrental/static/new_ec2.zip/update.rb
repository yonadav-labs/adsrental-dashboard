require 'open-uri'
require 'zip'

open('new_ec2.zip', 'wb') do |file|
  file << open('https://adsrental.com/static/new_ec2.zip').read
end

Zip::File.open('new_ec2.zip') do |zip_file|
    zip_file.each do |f|
        fpath = f.name
        puts f.name
        zip_file.extract(f, fpath) { true }
      end
end